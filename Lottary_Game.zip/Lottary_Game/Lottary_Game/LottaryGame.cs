﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace NewPractice
{
    class LottaryGame
    {
        /*
         Hint: If you want to do practice of loops, if else statement, jump statement, arrays (single and multi) then
         i would recommend you to create it as it is or it can be created even better. 
         */

        /*
         1: Draw a grid of numbers from 1 to 45 inside the grid.
         2: User could be able to nevigate cursor inside the grid.
         3: User could be able to select numbers by press space.
         4: All numbers should be green by press space one by one.
         5: Once all numbers are selected then by pressing Enter selected numbers can be submitted 
         6: After submission of numbers the final result should be displyed.
         7: User numbers should be DarkRed.
         8: Random numbers should be cyan.
         9: A unique random number should be blue.
        10: If user numbers are matched with random or unique number then those numbers should be green.
         */


        private int xGlobal { get; set; }
        private int number { get; set; }
        private int[] userSelectedNumber { get; set; }
        private int xAxis { get; set; }
        private int yAxis { get; set; }
        private int xAxisMax { get; set; }
        private int yAxisMax { get; set; }
        private int xAxisMin { get; set; }
        private int yAxisMin { get; set; }
        private int positionX { get; set; }
        private int postiionY { get; set; }
        private Random random { get; set; }
        private int[] randomValue { get; set; }
        private int uniqueValue { get; set; }

        private LottaryGame()
        {
            this.xGlobal = 0;
            this.number = 0;
            this.userSelectedNumber = new int[6];
            this.xAxis = 11;
            this.yAxis = 8;
            this.xAxisMax = 20;
            this.yAxisMax = 21;
            this.xAxisMin = 1;
            this.yAxisMin = 6;
            this.positionX = xAxis - xAxis + 1;
            this.postiionY = yAxis - yAxis + 2;
            this.random = new Random();
        }

        public static void PrintInstrucation()
        {
            int x = 0;
            int y = 20;
            Console.SetCursorPosition(x + y, y - y + 2);
            Console.WriteLine("Welcome to lottary game");
            Console.SetCursorPosition(x + y, y - y + 3);
            Console.WriteLine("-----------------------");
            Console.WriteLine("Before you start the game, please read all instructions carefully..");
            Console.WriteLine("\nInstructions of lottary Game\n");
            Console.WriteLine("1: You can nevigate the game cursor by using arrow keys, which is situated inside the grid.\n");
            Console.WriteLine("2: By pressing space you can select you desired number.\n");
            Console.WriteLine("3: You can select maximum six numbers\n");
            Console.WriteLine("4: Once all six numbers have been selected then by pressing enter all selected numbers can be submitted.\n");
            Console.WriteLine("5: If atleast 3 selected numbers are matched with random number then it can be counted as a winner with only three numbers.\n");
            Console.WriteLine("6: By pressing S lottary game can be started.\n\n");

            x = PrintAndMoveGoodLuck(x, y);
        }

        private static int PrintAndMoveGoodLuck(int x, int y)
        {
            for (int i = 0; i < 50; i++)
            {
                Thread.Sleep(100);
                Console.SetCursorPosition(x, y);
                Console.Write("Good Luck ;)");

                x++;

                if (i > 0)
                {
                    Console.SetCursorPosition(x - 2, y);
                    Console.Write(" ");
                }
            }

            return x;
        }

        private void PrintHeaderOfGraphicalBet()
        {
            int x = 0;
            int y = 1;

            Console.SetCursorPosition(x, y);
            Console.WriteLine("Welcome To The Graphical Lottary Game");

            for (int i = 0; i < 37; i++)
            {
                if (i < 35)
                {
                    Console.SetCursorPosition(x + i, y + 1);
                    Console.WriteLine("=");
                }
                else
                {
                    Console.SetCursorPosition(x + i, y + 1);
                    Console.WriteLine("=\n\n");
                }
            }
        }

        private void DrawCursor(int number)
        {
            if (number < 10)
            {
                Console.SetCursorPosition(xAxis, yAxis);
                Console.Write($"  {number} ", Console.BackgroundColor = ConsoleColor.Gray);
                Console.ResetColor();
            }
            else
            {
                Console.SetCursorPosition(xAxis, yAxis);
                Console.Write($" {number} ", Console.BackgroundColor = ConsoleColor.Gray);
                Console.ResetColor();
            }
        }

        public void MoveCursor(int[,] multiArray)
        {
            bool isEveryThingOk = true;
            bool isEveryThingFinished = false;
            bool isEnterPressed = false;

            while (true)
            {
                do
                {
                    number = multiArray[positionX, postiionY];

                    DrawCursor(number);

                    ConsoleKeyInfo key = Console.ReadKey(true);
                    switch (key.Key)
                    {
                        case ConsoleKey.RightArrow:
                            if (xAxis < xAxisMax)
                            {
                                if (number < 10)
                                {
                                    xAxis += 5;

                                    if (MatchUserNumber())
                                    {
                                        Console.SetCursorPosition(xAxis - 5, yAxis);
                                        Console.Write($"  {number} ", Console.BackgroundColor = ConsoleColor.Green);
                                        Console.ResetColor();
                                    }
                                    else
                                    {
                                        Console.SetCursorPosition(xAxis - 5, yAxis);
                                        Console.Write($"  {number} ", Console.BackgroundColor = ConsoleColor.Black);
                                        Console.ResetColor();
                                    }
                                }
                                else
                                {
                                    xAxis += 5;

                                    if (MatchUserNumber())
                                    {
                                        Console.SetCursorPosition(xAxis - 5, yAxis);
                                        Console.Write($" {number} ", Console.BackgroundColor = ConsoleColor.Green);
                                        Console.ResetColor();
                                    }
                                    else
                                    {
                                        Console.SetCursorPosition(xAxis - 5, yAxis);
                                        Console.Write($" {number} ", Console.BackgroundColor = ConsoleColor.Black);
                                        Console.ResetColor();
                                    }
                                }

                                postiionY++;
                            }

                            break;
                        case ConsoleKey.LeftArrow:
                            if (xAxis > xAxisMin)
                            {
                                if (number < 10)
                                {
                                    xAxis -= 5;

                                    if (MatchUserNumber())
                                    {
                                        Console.SetCursorPosition(xAxis + 5, yAxis);
                                        Console.Write($"  {number} ", Console.BackgroundColor = ConsoleColor.Green);
                                        Console.ResetColor();
                                    }
                                    else
                                    {
                                        Console.SetCursorPosition(xAxis + 5, yAxis);
                                        Console.Write($"  {number} ", Console.BackgroundColor = ConsoleColor.Black);
                                        Console.ResetColor();
                                    }
                                }
                                else
                                {
                                    xAxis -= 5;

                                    if (MatchUserNumber())
                                    {
                                        Console.SetCursorPosition(xAxis + 5, yAxis);
                                        Console.Write($" {number} ", Console.BackgroundColor = ConsoleColor.Green);
                                        Console.ResetColor();
                                    }
                                    else
                                    {
                                        Console.SetCursorPosition(xAxis + 5, yAxis);
                                        Console.Write($" {number} ", Console.BackgroundColor = ConsoleColor.Black);
                                        Console.ResetColor();
                                    }
                                }

                                postiionY--;
                            }

                            break;
                        case ConsoleKey.DownArrow:
                            if (yAxis < yAxisMax)
                            {
                                if (number < 10)
                                {
                                    yAxis += 2;

                                    if (MatchUserNumber())
                                    {
                                        Console.SetCursorPosition(xAxis, yAxis - 2);
                                        Console.Write($"  {number} ", Console.BackgroundColor = ConsoleColor.Green);
                                        Console.ResetColor();
                                    }
                                    else
                                    {
                                        Console.SetCursorPosition(xAxis, yAxis - 2);
                                        Console.Write($"  {number} ", Console.BackgroundColor = ConsoleColor.Black);
                                        Console.ResetColor();
                                    }
                                }
                                else
                                {
                                    yAxis += 2;

                                    if (MatchUserNumber())
                                    {
                                        Console.SetCursorPosition(xAxis, yAxis - 2);
                                        Console.Write($" {number} ", Console.BackgroundColor = ConsoleColor.Green);
                                        Console.ResetColor();
                                    }
                                    else
                                    {
                                        Console.SetCursorPosition(xAxis, yAxis - 2);
                                        Console.Write($" {number} ", Console.BackgroundColor = ConsoleColor.Black);
                                        Console.ResetColor();
                                    }
                                }

                                positionX++;
                            }

                            break;
                        case ConsoleKey.UpArrow:
                            if (yAxis > yAxisMin)
                            {
                                if (number < 10)
                                {
                                    yAxis -= 2;

                                    if (MatchUserNumber())
                                    {
                                        Console.SetCursorPosition(xAxis, yAxis + 2);
                                        Console.Write($"  {number} ", Console.BackgroundColor = ConsoleColor.Green);
                                        Console.ResetColor();
                                    }
                                    else
                                    {
                                        Console.SetCursorPosition(xAxis, yAxis + 2);
                                        Console.Write($"  {number} ", Console.BackgroundColor = ConsoleColor.Black);
                                        Console.ResetColor();
                                    }
                                }
                                else
                                {
                                    yAxis -= 2;

                                    if (MatchUserNumber())
                                    {
                                        Console.SetCursorPosition(xAxis, yAxis + 2);
                                        Console.Write($" {number} ", Console.BackgroundColor = ConsoleColor.Green);
                                        Console.ResetColor();
                                    }
                                    else
                                    {
                                        Console.SetCursorPosition(xAxis, yAxis + 2);
                                        Console.Write($" {number} ", Console.BackgroundColor = ConsoleColor.Black);
                                        Console.ResetColor();
                                    }
                                }

                                positionX--;
                            }

                            break;
                        case ConsoleKey.Spacebar:
                            if (number < 10)
                            {
                                Console.SetCursorPosition(xAxis, yAxis);
                                Console.Write($"  {number} ", Console.BackgroundColor = ConsoleColor.Green);
                                Console.ResetColor();
                            }
                            else
                            {
                                Console.SetCursorPosition(xAxis, yAxis);
                                Console.Write($" {number} ", Console.BackgroundColor = ConsoleColor.Green);
                                Console.ResetColor();
                            }

                            if (this.xGlobal < userSelectedNumber.Length)
                            {
                                if (MatchUserNumber())
                                {
                                    isEveryThingOk = false;
                                }
                                else
                                {
                                    userSelectedNumber[this.xGlobal] = number;

                                    this.xGlobal++;

                                    isEveryThingOk = true;

                                    if (this.xGlobal == 6)
                                    {
                                        do
                                        {
                                            ConsoleKeyInfo consoleKey = Console.ReadKey(true);
                                            if (consoleKey.Key == ConsoleKey.Enter)
                                            {
                                                Console.Clear();

                                                DoColorToAllSelectedNumber(multiArray);

                                                ShowUserNumber();

                                                ShowRandomNumber();

                                                GenerateResult();

                                                uniqueValue = 0;

                                                xAxis = 11;

                                                yAxis = 8;

                                                positionX = xAxis - xAxis + 1;

                                                postiionY = yAxis - yAxis + 2;

                                                isEveryThingFinished = true;

                                                isEnterPressed = true;

                                                break;
                                            }
                                            else
                                            {
                                                isEnterPressed = false;
                                            }
                                        }
                                        while (isEnterPressed == false);

                                        break;
                                    }
                                    else
                                    {
                                        isEveryThingFinished = false;
                                    }

                                    DoGreenColorOfUserSelectedNumber(multiArray);
                                }
                            }

                            break;
                        default:
                            break;
                    }
                }
                while (isEveryThingOk == false);

                if (isEveryThingFinished == true)
                {
                    break;
                }
            }
        }

        private void DrawGrid()
        {
            int gridLength = 9;
            int gridBreath = 5;
            int[,] multiArray = new int[gridLength, gridBreath];
            int count = 1;

            PrintHeaderOfGraphicalBet();

            for (int i = 0; i < multiArray.GetLength(0); i++)
            {
                for (int k = 0; k < multiArray.GetLength(1); k++)
                {
                    if (k == multiArray.GetLength(1) - 1)
                    {
                        Console.Write("+----+");
                    }
                    else
                    {
                        Console.Write("+----");
                    }
                }

                Console.WriteLine();

                for (int j = 0; j < multiArray.GetLength(1); j++)
                {
                    if (count < 10)
                    {
                        Console.Write("|");
                        Console.Write("  ");
                        Console.Write(multiArray[i, j] = count++);
                        Console.Write(" ");
                    }
                    else
                    {
                        Console.Write("|");
                        Console.Write(" ");
                        Console.Write(multiArray[i, j] = count++);
                        Console.Write(" ");
                    }
                }

                Console.Write("|");
                Console.WriteLine();
            }

            for (int l = 0; l < multiArray.GetLength(1); l++)
            {
                if (l == multiArray.GetLength(1) - 1)
                {
                    Console.Write("+----+");
                }
                else
                {
                    Console.Write("+----");
                }
            }

            MoveCursor(multiArray);
        }

        private void DoGreenColorOfUserSelectedNumber(int[,] multiArray)
        {
            int count = 1;

            PrintHeaderOfGraphicalBet();

            for (int i = 0; i < multiArray.GetLength(0); i++)
            {
                for (int k = 0; k < multiArray.GetLength(1); k++)
                {
                    if (k == multiArray.GetLength(1) - 1)
                    {
                        Console.Write("+----+");
                    }
                    else
                    {
                        Console.Write("+----");
                    }
                }

                Console.WriteLine();

                for (int j = 0; j < multiArray.GetLength(1); j++)
                {
                    if (count < 10)
                    {
                        if (MatchUserNumber(count))
                        {
                            Console.Write("|");
                            Console.BackgroundColor = ConsoleColor.Green;
                            Console.Write("  ");
                            Console.Write(count++);
                            Console.Write(" ");
                            Console.ResetColor();
                        }
                        else
                        {
                            Console.Write("|");
                            Console.Write("  ");
                            Console.Write(count++);
                            Console.Write(" ");
                        }

                    }
                    else
                    {
                        if (MatchUserNumber(count))
                        {
                            Console.Write("|");
                            Console.BackgroundColor = ConsoleColor.Green;
                            Console.Write(" ");
                            Console.Write(count++);
                            Console.Write(" ");
                            Console.ResetColor();
                        }
                        else
                        {
                            Console.Write("|");
                            Console.Write(" ");
                            Console.Write(multiArray[i, j] = count++);
                            Console.Write(" ");
                        }
                    }
                }

                Console.Write("|");
                Console.WriteLine();
            }

            for (int l = 0; l < multiArray.GetLength(1); l++)
            {
                if (l == multiArray.GetLength(1) - 1)
                {
                    Console.Write("+----+");
                }
                else
                {
                    Console.Write("+----");
                }
            }
        }

        protected bool MatchUserNumber()
        {
            bool isMatched = false;

            for (int i = 0; i < userSelectedNumber.Length; i++)
            {
                if (userSelectedNumber[i] == number)
                {
                    isMatched = true;
                    break;
                }
                else
                {
                    isMatched = false;
                }
            }

            return isMatched;
        }

        protected bool MatchUserNumber(int count)
        {
            bool isMatched = false;

            for (int i = 0; i < userSelectedNumber.Length; i++)
            {
                if (userSelectedNumber[i] == count)
                {
                    isMatched = true;
                    break;
                }
                else
                {
                    isMatched = false;
                }
            }

            return isMatched;
        }

        protected int[] GenerateRandomNumber()
        {
            int value = 0;
            bool isUnique = false;
            int[] randomNumber = new int[6];

            for (int i = 0; i < randomNumber.Length; i++)
            {
                do
                {
                    value = random.Next(1, 46);

                    if (CheckUniqueness(randomNumber, value, i))
                    {
                        isUnique = true;
                    }
                    else
                    {
                        isUnique = false;
                    }

                    if (isUnique == false)
                    {
                        randomNumber[i] = value;
                        isUnique = false;
                        break;
                    }
                }
                while (isUnique == true);
            }

            this.randomValue = randomNumber;

            return randomNumber;
        }

        protected int GenerateUniqueNumber()
        {
            int uniqueNumber = random.Next(1, 46);

            this.uniqueValue = uniqueNumber;

            return uniqueNumber;
        }

        private static bool CheckUniqueness(int[] randomNumber, int value, int i)
        {
            bool isUnique = false;

            for (int j = 0; j < i; j++)
            {
                if (randomNumber[j] == value)
                {
                    isUnique = true;
                    break;
                }
                else
                {
                    isUnique = false;
                }
            }

            return isUnique;
        }

        protected bool MatchRandomNumberWithGridNumber(int count)
        {
            bool isMatched = false;

            for (int i = 0; i < randomValue.Length; i++)
            {
                if (randomValue[i] == count)
                {
                    isMatched = true;
                    break;
                }
                else
                {
                    isMatched = false;
                }
            }

            return isMatched;
        }

        protected bool MatchUniqueNumberWithGridNumber(int count)
        {
            bool isMatched = false;

            if (count == uniqueValue)
            {
                isMatched = true;
            }
            else
            {
                isMatched = false;
            }

            return isMatched;
        }

        protected bool CompareUniqueNumberWithUserNumber()
        {
            bool isMatched = false;

            for (int i = 0; i < userSelectedNumber.Length; i++)
            {
                if (userSelectedNumber[i] == uniqueValue)
                {
                    isMatched = true;
                    break;
                }
                else
                {
                    isMatched = false;
                }
            }

            return isMatched;
        }

        public void DoColorToAllSelectedNumber(int[,] multiArray)
        {
            int count = 1;

            PrintHeaderOfGraphicalBet();
            GenerateRandomNumber();
            GenerateUniqueNumber();

            for (int i = 0; i < multiArray.GetLength(0); i++)
            {
                for (int k = 0; k < multiArray.GetLength(1); k++)
                {
                    if (k == multiArray.GetLength(1) - 1)
                    {
                        Console.Write("+----+");
                    }
                    else
                    {
                        Console.Write("+----");
                    }
                }
                Console.WriteLine();

                for (int j = 0; j < multiArray.GetLength(1); j++)
                {
                    if (count < 10)
                    {
                        if (MatchUserNumber(count))
                        {
                            if (MatchRandomNumberWithGridNumber(count))
                            {
                                if (MatchUniqueNumberWithGridNumber(count))
                                {
                                    Console.Write("|");
                                    Console.BackgroundColor = ConsoleColor.Green;
                                    Console.Write("  ");
                                    Console.Write(count++);
                                    Console.Write(" ");
                                    Console.ResetColor();
                                }
                                else
                                {
                                    Console.Write("|");
                                    Console.BackgroundColor = ConsoleColor.Green;
                                    Console.Write("  ");
                                    Console.Write(count++);
                                    Console.Write(" ");
                                    Console.ResetColor();
                                }
                            }
                            else if (MatchUniqueNumberWithGridNumber(count))
                            {
                                Console.Write("|");
                                Console.BackgroundColor = ConsoleColor.Green;
                                Console.Write("  ");
                                Console.Write(count++);
                                Console.Write(" ");
                                Console.ResetColor();
                            }
                            else
                            {
                                Console.Write("|");
                                Console.BackgroundColor = ConsoleColor.DarkRed;
                                Console.Write("  ");
                                Console.Write(count++);
                                Console.Write(" ");
                                Console.ResetColor();
                            }
                        }
                        else if (MatchRandomNumberWithGridNumber(count))
                        {
                            Console.Write("|");
                            Console.BackgroundColor = ConsoleColor.DarkBlue;
                            Console.Write("  ");
                            Console.Write(count++);
                            Console.Write(" ");
                            Console.ResetColor();
                        }
                        else if (MatchUniqueNumberWithGridNumber(count))
                        {
                            Console.Write("|");
                            Console.BackgroundColor = ConsoleColor.DarkMagenta;
                            Console.Write("  ");
                            Console.Write(count++);
                            Console.Write(" ");
                            Console.ResetColor();
                        }
                        else
                        {
                            Console.Write("|");
                            Console.Write("  ");
                            Console.Write(count++);
                            Console.Write(" ");
                        }
                    }
                    else
                    {
                        if (MatchUserNumber(count))
                        {
                            if (MatchRandomNumberWithGridNumber(count))
                            {
                                if (MatchUniqueNumberWithGridNumber(count))
                                {
                                    Console.Write("|");
                                    Console.BackgroundColor = ConsoleColor.Green;
                                    Console.Write(" ");
                                    Console.Write(count++);
                                    Console.Write(" ");
                                    Console.ResetColor();
                                }
                                else
                                {
                                    Console.Write("|");
                                    Console.BackgroundColor = ConsoleColor.Green;
                                    Console.Write(" ");
                                    Console.Write(count++);
                                    Console.Write(" ");
                                    Console.ResetColor();
                                }
                            }
                            else if (MatchUniqueNumberWithGridNumber(count))
                            {
                                Console.Write("|");
                                Console.BackgroundColor = ConsoleColor.Green;
                                Console.Write(" ");
                                Console.Write(count++);
                                Console.Write(" ");
                                Console.ResetColor();
                            }
                            else
                            {
                                Console.Write("|");
                                Console.BackgroundColor = ConsoleColor.DarkRed;
                                Console.Write(" ");
                                Console.Write(count++);
                                Console.Write(" ");
                                Console.ResetColor();
                            }
                        }
                        else if (MatchRandomNumberWithGridNumber(count))
                        {
                            Console.Write("|");
                            Console.BackgroundColor = ConsoleColor.DarkBlue;
                            Console.Write(" ");
                            Console.Write(count++);
                            Console.Write(" ");
                            Console.ResetColor();
                        }
                        else if (MatchUniqueNumberWithGridNumber(count))
                        {
                            Console.Write("|");
                            Console.BackgroundColor = ConsoleColor.DarkMagenta;
                            Console.Write(" ");
                            Console.Write(count++);
                            Console.Write(" ");
                            Console.ResetColor();
                        }
                        else
                        {
                            Console.Write("|");
                            Console.Write(" ");
                            Console.Write(count++);
                            Console.Write(" ");
                        }
                    }
                }
                Console.Write("|");
                Console.WriteLine();
            }
            for (int l = 0; l < multiArray.GetLength(1); l++)
            {
                if (l == multiArray.GetLength(1) - 1)
                {
                    Console.Write("+----+");
                }
                else
                {
                    Console.Write("+----");
                }
            }
        }

        public void ShowUserNumber()
        {
            Console.SetCursorPosition(40, 5);
            Console.Write("User numbers are: ");
            for (int i = 0; i < userSelectedNumber.Length; i++)
            {
                if (i < userSelectedNumber.Length - 1)
                {
                    Console.Write(userSelectedNumber[i] + " , ");
                }
                else
                {
                    Console.Write(userSelectedNumber[i]);
                }
            }
        }

        public void ShowRandomNumber()
        {
            Console.SetCursorPosition(40, 7);
            Console.Write("Random numbers are: ");

            for (int i = 0; i < randomValue.Length; i++)
            {
                if (i < randomValue.Length - 1)
                {
                    Console.Write(randomValue[i] + " , ");
                }
                else
                {
                    Console.Write(randomValue[i]);
                }
            }
            Console.Write("   ZZ:  " + uniqueValue);
        }

        private int GenerateResult()
        {
            int count = 0; // it will help to make result :D.

            for (int i = 0; i < userSelectedNumber.Length; i++)
            {
                for (int j = 0; j < randomValue.Length; j++)
                {
                    if (userSelectedNumber[i] == randomValue[j])
                    {
                        count++;
                    }
                }
            }

            Console.WriteLine("\n\n");
            if (count == 3)
            {
                if (CompareUniqueNumberWithUserNumber())
                {
                    Console.SetCursorPosition(40, 9);
                    Console.WriteLine("Your three numbers and the unique number are matched.");
                }
                else
                {
                    Console.SetCursorPosition(40, 9);
                    Console.WriteLine("Your three numbers are matched.");
                }
            }
            else if (count == 4)
            {
                if (CompareUniqueNumberWithUserNumber())
                {
                    Console.SetCursorPosition(40, 9);
                    Console.WriteLine("Your four numbers and the unique number are matched.");
                }
                else
                {
                    Console.SetCursorPosition(40, 9);
                    Console.WriteLine("Your four numbers are matched.");
                }
            }
            else if (count == 5)
            {
                if (CompareUniqueNumberWithUserNumber())
                {
                    Console.SetCursorPosition(40, 9);
                    Console.WriteLine("Your five numbers and the unique number are matched.");
                }
                else
                {
                    Console.SetCursorPosition(40, 9);
                    Console.WriteLine("Your five numbers are matched.");
                }
            }
            else if (count == 6)
            {
                if (CompareUniqueNumberWithUserNumber())
                {
                    Console.SetCursorPosition(40, 9);
                    Console.WriteLine("Your six numbers and the unique number are matched.");
                }
                else
                {
                    Console.SetCursorPosition(40, 9);
                    Console.WriteLine("Your six numbers are matched.");
                }
            }
            else if (CompareUniqueNumberWithUserNumber())
            {
                Console.SetCursorPosition(40, 9);
                Console.WriteLine("Unique number is matched.");
            }
            else
            {
                Console.SetCursorPosition(40, 9);
                Console.WriteLine("You have lost the game");
            }

            for (int i = 0; i < userSelectedNumber.Length; i++)
            {
                userSelectedNumber[i] = 0;
                randomValue[i] = 0;
            }

            return count;
        }

        private static void Main(string[] arg)
        {
            bool isCorrect = false;
            int x = 40;
            int y = 12;
            Console.CursorVisible = false;
            bool isApplicationClosed = false;

            LottaryGame.PrintInstrucation();

            ConsoleKeyInfo keyOne = Console.ReadKey(true);

            do
            {
                keyOne = Console.ReadKey(true);

                if (keyOne.Key == ConsoleKey.S)
                {
                    do
                    {
                        Console.Clear();

                        LottaryGame grid = new LottaryGame();

                        grid.DrawGrid();

                        Console.SetCursorPosition(x, y);
                        Console.Write("Press Enter to go back or press any other key to exit the game.");

                        ConsoleKeyInfo key = Console.ReadKey(true);

                        if (key.Key == ConsoleKey.Enter)
                        {
                            isCorrect = true;
                            Console.Clear();
                        }
                        else
                        {
                            isCorrect = false;
                            isApplicationClosed = true;
                            break;
                        }
                    }

                    while (isCorrect == true);
                }
                else if (keyOne.Key == ConsoleKey.Backspace)
                {
                    isCorrect = true;
                    break;
                }
                else
                {
                    Console.SetCursorPosition(0, 19);
                    Console.Write("Invalid Input.. Press S to start the game or Press Backspace to close the game.");
                    isCorrect = false;
                }

                if (isApplicationClosed)
                {
                    break;
                }
            }

            while (isCorrect == false);
        }
    }
}
